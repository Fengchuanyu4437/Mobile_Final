package com.example.feng_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private EditText et_username;
    private EditText et_password;
    private EditText et_password2;
    private EditText et_email;
    private Button et_login;
    private Button et_register;
    private String LastTimePic="no";
    private CheckBox et_checkbox;
    ImageView last_time;

    private SharedPreferences sharedPreferences;
    private final String sharedPrefFileName =
            "com.example.feng_final.LastTime_Setting.pref";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Map<String,String>userInfo= SaveInfo.getSaveInformation(this);
        if(userInfo!=null)
        {
            et_username.setText(userInfo.get("username"));
            et_password.setText(userInfo.get("password"));
        }
        et_username=(EditText) findViewById(R.id.Account);
        et_password=(EditText) findViewById(R.id.PassWord);
        et_checkbox=(CheckBox) findViewById(R.id.RememberPwd);
        et_login=(Button) findViewById(R.id.LogIn);
        et_register=(Button) findViewById(R.id.Register);
//        et_login.setOnClickListener(new MyButton());
//        et_register.setOnClickListener(new MyButton());
        last_time=findViewById(R.id.Last_time);

        Drawable myDrawable=getResources().getDrawable(R.drawable.gou);
        Drawable myDrawable2=getResources().getDrawable(R.drawable.mao);
        Drawable myDrawableC=getResources().getDrawable(R.drawable.mercy);
        sharedPreferences = getSharedPreferences(sharedPrefFileName,
                MODE_PRIVATE);
        LastTimePic=sharedPreferences.getString("Last_time_pic","");
        if(!LastTimePic.isEmpty()){
            if(LastTimePic.equals("dog")) {
                last_time.setImageDrawable(myDrawable);
            }
            else {
                last_time.setImageDrawable(myDrawable2);
            }
        }
        else
            {
                 last_time.setImageDrawable(myDrawableC);
            }

    }
        public void signInonClick(View view) {

            String username = et_username.getText().toString().trim();
            String password = et_password.getText().toString().trim();
                    if(TextUtils.isEmpty(username)||TextUtils.isEmpty(password))
                    {
                        Toast.makeText(LoginActivity.this,"username or password cant be empty",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if (et_checkbox.isChecked()) {
                        }
                        Toast.makeText(LoginActivity.this, "Login in successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, BuildFileActivity.class);
                        startActivity(intent);
                    }
            }
            public void registerOnclick(View view)
            {
                Intent intent=new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);

            }
        }



