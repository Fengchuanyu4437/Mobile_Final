package com.example.feng_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class UserActivity extends AppCompatActivity {

    TextView Gender_text;
    ImageView profile_pic;
    TextView User_name;
    TextView User_age;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        String Profile_pic=getIntent().getStringExtra("pic_key");
        String Profile_gender=getIntent().getStringExtra("gender_key");
        Log.d("Profile_pic",Profile_pic);
        Log.d("Profile_gender",Profile_gender);
        String user_name=getIntent().getStringExtra("Your_name");
        String user_age=getIntent().getStringExtra("Your_age");
        profile_pic=findViewById(R.id.profile_pic);
        Gender_text=findViewById(R.id.Gender_text);
        User_name=findViewById(R.id.user_name);
        User_age=findViewById(R.id.user_age);
       Drawable myDrawable=getResources().getDrawable(R.drawable.gou);
        Drawable myDrawable2=getResources().getDrawable(R.drawable.mao);


       if(Profile_pic.equals("dog")) {
           profile_pic.setImageDrawable(myDrawable);
       }
         else {
           profile_pic.setImageDrawable(myDrawable2);
       }

       if(Profile_gender.equals("boy")) {

           Gender_text.setText("You are a boy");
       }
          else
              {
               Gender_text.setText("You are a girl");
       }

         User_name.setText(user_name);
          User_age.setText(user_age);

    }
    public void BackLoginOnclick(View view)
    {
        Intent intent=new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}