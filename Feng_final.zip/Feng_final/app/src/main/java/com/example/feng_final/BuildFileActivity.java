package com.example.feng_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class BuildFileActivity extends AppCompatActivity {
  public static final String cat_pic="cat";
  public static final String dog_pic="dog";
  public static String picKey;
  public static  String GenderKey;
  public static final String Gender_boy="boy";
  public static final String Gender_girl="girl";
  public static String Your_name;
  public static String Your_age;
  public TextView input_name;
  public TextView input_age;
  private String LastTimePic;
  private SharedPreferences sharedPreferences;
    private final String sharedPrefFileName =
            "com.example.feng_final.LastTime_Setting.pref";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        input_name=findViewById(R.id.Your_name);
        input_age=findViewById(R.id.Your_Age);

        sharedPreferences = getSharedPreferences(sharedPrefFileName,
                MODE_PRIVATE);

    }
    public void radioButtonOnclicked(View view) {
        RadioButton radioButton = (RadioButton) view;
        boolean checked = radioButton.isChecked();
        int clickedId = radioButton.getId();

        if (checked) {
            switch (clickedId) {
                case R.id.radio_male:
                    Toast.makeText(this, "Male", Toast.LENGTH_SHORT).show();
                    GenderKey=Gender_boy;
                    break;
                case R.id.radio_female:
                    Toast.makeText(this, "Female", Toast.LENGTH_SHORT).show();
                    GenderKey=Gender_girl;
                    break;
                default:
                    break;
            }
        }
    }
    public void dog_onclick(View view)
    {
        Toast.makeText(this, "dog", Toast.LENGTH_SHORT).show();
        picKey = dog_pic;
    }
    public void cat_onclick(View view)
    {
        Toast.makeText(this, "cat", Toast.LENGTH_SHORT).show();
        picKey = cat_pic;
    }
    public void BuildOnClicked(View view)
    {
        Your_name=input_name.getText().toString();
        Your_age=input_age.getText().toString();
        Intent intent3=new Intent(this,UserActivity.class);
        intent3.putExtra("pic_key",picKey);
        intent3.putExtra("gender_key",GenderKey);
        intent3.putExtra("Your_name",Your_name);
        intent3.putExtra("Your_age",Your_age);
        startActivity(intent3);

    }
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Last_time_pic",picKey);

        editor.apply();
    }
}