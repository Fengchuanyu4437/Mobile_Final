package com.example.feng_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    private  EditText  reg_username ;
    private   EditText reg_password;
    private EditText reg_password2;
    private EditText reg_email;
   private Button sure;
   private Button login;
   private RegisterDatabase mydaba;
//    private SharedPreferences sharedPreferences;
//    private final String sharedPrefFileName =
//            "com.example.feng_final.LastTime_Setting.pref";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        reg_username = (EditText) findViewById(R.id.reg_username);
        reg_password = (EditText) findViewById(R.id.reg_password);
        reg_password2 = (EditText) findViewById(R.id.reg_password2);
        reg_email=(EditText) findViewById(R.id.reg_email);
      sure=(Button) findViewById(R.id.reg_sure);
      login=(Button) findViewById(R.id.reg_login);

      mydaba=new RegisterDatabase(this,"book.db",null,1);
//      Button creatDB=findViewById(R.id.creatdb);
//      sure.setOnClickListener(new RegisterButton());
//      login.setOnClickListener(new RegisterButton());

//        sharedPreferences = getSharedPreferences(sharedPrefFileName,
//                MODE_PRIVATE);

    }

 public void dbOnclick(View view)
 {
     mydaba.getWritableDatabase();
 }
    public void registeronClick(View view)
        {
         String username=reg_username.getText().toString().trim();
          String password=reg_password.getText().toString().trim();
          String password2=reg_password2.getText().toString().trim();
          String mail=reg_email.getText().toString().trim();

              if(TextUtils.isEmpty(username)||TextUtils.isEmpty(password)||TextUtils.isEmpty(password2)||TextUtils.isEmpty(mail)) {
                        Toast.makeText(RegisterActivity.this,"Any field can't be empty",Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        if(TextUtils.equals(password,password2))
                        {
                            SaveInfo.SaveInformation(RegisterActivity.this,username,password,password2,mail);
                            Toast.makeText(RegisterActivity.this,"register successful,pleast back to login in",Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(RegisterActivity.this,"different input password",Toast.LENGTH_SHORT).show();
                        }
                    }
            }
            public void BackOnclick(View view)
            {
                Intent intent=new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }


//    @Override
//    protected void onPause() {
//        super.onPause();
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//     editor.putString("save_username",username);
//       editor.putString("save_password",password);
//        editor.apply();
//    }

}